/*
    CIT 281 Project 1
    Name: Tanner Gill
*/

const days = ['sun', 'mon', 'tues', 'wed', 'thur', 'fri', 'sat', 'sun'];
let day = days[new Date().getDay()];
console.log(day);
